package com.example.a21_unit_converter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity<adapter> extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText userInput;
    TextView Value1;
    TextView Value2;
    TextView Value3;
    TextView Value4;
    TextView Units1;
    TextView Units2;
    TextView Units3;
    TextView Units4;
    ImageButton convertMetreButton;
    ImageButton convertTempButton;
    ImageButton convertMassButton;
    Spinner optionsSpinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        optionsSpinner = (Spinner) findViewById(R.id.optionsSpinner);
        optionsSpinner.setOnItemSelectedListener(this);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.options, android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        optionsSpinner.setAdapter(adapter);
        userInput = findViewById(R.id.userInput);
        Value1 = findViewById(R.id.Value1);
        Value2 = findViewById(R.id.Value2);
        Value3 = findViewById(R.id.Value3);
        Value4 = findViewById(R.id.Value4);
        Units1 = findViewById(R.id.Units1);
        Units2 = findViewById(R.id.Units2);
        Units3 = findViewById(R.id.Units3);
        Units4 = findViewById(R.id.Units4);
        convertMetreButton = findViewById(R.id.convertMetricButton);
        convertTempButton = findViewById(R.id.convertMetricButton);
        convertMassButton = findViewById(R.id.convertMetricButton);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {

    }
    public void convertMetre(View view) {
        Double input = Double.parseDouble(userInput.getText().toString());
        String text = optionsSpinner.getSelectedItem().toString();
        if (text.equals("Metre")) {
            Double v1 = input * 100;
            Double v2 = input * 3.2808;
            Double v3 = input * 39.3701;
            Value1.setText(String.format("%.2f", v1));
            Value2.setText(String.format("%.2f", v2));
            Value3.setText(String.format("%.2f", v3));
            Value1.setVisibility(View.VISIBLE);
            Value2.setVisibility(View.VISIBLE);
            Value3.setVisibility(View.VISIBLE);
            Value4.setVisibility(View.INVISIBLE);
            Units1.setVisibility(View.VISIBLE);
            Units2.setVisibility(View.VISIBLE);
            Units3.setVisibility(View.VISIBLE);
            Units4.setVisibility(View.INVISIBLE);
            Units1.setText("Centimetres");
            Units2.setText("Inches");
            Units3.setText("Feet");
        } else {
            Toast.makeText(MainActivity.this, "Please select the correct conversion icon.", Toast.LENGTH_LONG).show();
        }
    }
    public void covertTemp(View view){
        Double input = Double.parseDouble(userInput.getText().toString());
        String text = optionsSpinner.getSelectedItem().toString();
        if (text.equals("Celsius")) {
            Double v1 = (input * (9/5)) + 32;
            Double v2 = input + 273.15;
            Value1.setVisibility(View.VISIBLE);
            Value2.setVisibility(View.VISIBLE);
            Value3.setVisibility(View.INVISIBLE);
            Value4.setVisibility(View.INVISIBLE);
            Units1.setVisibility(View.VISIBLE);
            Units2.setVisibility(View.VISIBLE);
            Units3.setVisibility(View.INVISIBLE);
            Units4.setVisibility(View.INVISIBLE);
            Value1.setText(String.format("%.2f", v1));
            Value2.setText(String.format("%.2f", v2));
            Units1.setText("Fahrenheit");
            Units2.setText("Kelvin");
        } else {
            Toast.makeText(MainActivity.this, "Please select the correct conversion icon.", Toast.LENGTH_LONG).show();
        }
    }
    public void convertMass(View view){
        Double input = Double.parseDouble(userInput.getText().toString());
        String text = optionsSpinner.getSelectedItem().toString();
        if (text.equals("Kilograms")) {
            Double v1 = input * 1000;
            Double v2 = input * 35.274;
            Double v3 = input * 2.2046;
            Value1.setVisibility(View.VISIBLE);
            Value2.setVisibility(View.VISIBLE);
            Value3.setVisibility(View.VISIBLE);
            Value4.setVisibility(View.INVISIBLE);
            Units1.setVisibility(View.VISIBLE);
            Units2.setVisibility(View.VISIBLE);
            Units3.setVisibility(View.VISIBLE);
            Units4.setVisibility(View.INVISIBLE);
            Value1.setText(String.format("%.2f", v1));
            Value2.setText(String.format("%.2f", v2));
            Value3.setText(String.format("%.2f", v3));
            Units1.setText("Grams");
            Units2.setText("Ounces");
            Units3.setText("Pounds");
        } else {
            Toast.makeText(MainActivity.this, "Please select the correct conversion icon.", Toast.LENGTH_LONG).show();
        }
    }
}

//Sites helping me with the spinner:
//https://www.javatpoint.com/android-spinner-example#:~:text=Android%20Spinner%20is%20like%20the,can%20select%20only%20one%20value.
//https://developer.android.com/guide/topics/ui/controls/spinner#java
//https://www.tutorialspoint.com/how-to-get-spinner-value-in-android
//Site helped me with resizing the image buttons:
//https://stackoverflow.com/questions/15116393/fit-image-in-imagebutton-in-android
package com.example.quizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button startButton;
    EditText nameText;
    String Name;
    Integer Score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startButton = findViewById(R.id.startButton);
        nameText = findViewById(R.id.nameText);
        startButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick (View v){
                Name = nameText.getText().toString();
                Intent intent = new Intent(MainActivity.this, questionActivity.class);
                intent.putExtra("Name", nameText.getText().toString());
                intent.putExtra("Score", Score);
                startActivityForResult(intent, RESULT_FIRST_USER);
            }
        });
    }
}
package com.example.quizapp;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Random;

import java.security.InvalidParameterException;

public class questionActivity extends AppCompatActivity {

    Button answerButton1;
    Button answerButton2;
    Button answerButton3;
    Button answerButton4;
    Button nextButton;
    TextView questionPrompt;
    TextView questionTitle;
    TextView welcomePrompt;
    TextView progressView;
    ProgressBar progressBar;
    Boolean answerTrue;
    Button answerButton = null;
    Button selectedButton = null;
    int questionNumber;
    int questions = 0;
    boolean submitted;
    Random rand = new Random();
    int Score;
    int answer;

    protected void newQuestion()
    {
        Button[] buttons = new Button[] {answerButton1, answerButton2, answerButton3, answerButton4};
        submitted = false;
        answerTrue = false;
        answerButton = null;
        selectedButton = null;
        if (questionNumber == 1)
        {
            enableButtons("Enabled", "Enabled", "Enabled", "Disabled", buttons);
            questionTitle.setText("APIs");
            questionPrompt.setText("What is the main purpose of an API?");
            buttons[1].setText("Abstracting implementation of objects and actions from the programmer");
            buttons[0].setText("Abstracting functionality of buttons and text views from the user");
            buttons[2].setText("Contains a code file from a selected version of the code");
            this.answer = 2;
        }
        else if (questionNumber == 2)
        {
            enableButtons("Enabled", "Enabled", "Enabled", "Disabled", buttons);
            questionTitle.setText("ViewGroups");
            questionPrompt.setText("Define a ViewGroup");
            buttons[2].setText("A special view containing multiple views");
            buttons[1].setText("A list of views");
            buttons[0].setText("Multiple views with or without any connection");
            this.answer = 3;
        }
        else if (questionNumber == 3)
        {
            enableButtons("Enabled", "Enabled", "Enabled", "Enabled", buttons);
            questionTitle.setText("Pop up messages");
            questionPrompt.setText("Definition of a particular object which displays a pop up message from the bottom of the screen");
            buttons[3].setText("Toast");
            buttons[1].setText("View");
            buttons[2].setText("Spinner");
            buttons[0].setText("TextView");
            this.answer = 4;
        }
        else if (questionNumber == 4)
        {
            enableButtons("Enabled", "Enabled", "Enabled", "Enabled", buttons);
            questionTitle.setText("Activity");
            questionPrompt.setText("Which of the following methods apart from onDestroy is capable of killing the activity?");
            buttons[2].setText("onCreate()");
            buttons[3].setText("onDestroy");
            buttons[1].setText("onStop");
            buttons[0].setText("onRestart");
            this.answer = 3;
        }
        else if (questionNumber == 5)
        {
            questionTitle.setText("Activity");
            enableButtons("Enabled", "Enabled", "Disabled", "Disabled", buttons);
            questionPrompt.setText("When the user switches to another activity, that activity is no longer visible. Is the activity stopped or paused?");
            buttons[0].setText("Stopped");
            buttons[1].setText("Paused");
            this.answer = 1;
        }
    }
    protected void enableButtons(String enabler1, String enabler2, String enabler3, String enabler4, Button[] buttons)
    {
        String[] enablers = new String[] {enabler1, enabler2, enabler3, enabler4};
        for (int i = 0; i < enablers.length; i++)
        {
            if (enablers[i] == "Enabled")
            {
                buttons[i].setEnabled(true);
                buttons[i].setVisibility(View.VISIBLE);
                buttons[i].setBackgroundColor(Color.WHITE);
            }
            else if (enablers[i] == "Disabled")
            {
                buttons[i].setEnabled(false);
                buttons[i].setVisibility(View.INVISIBLE);
            }
            else
            {
                throw new InvalidParameterException();
            }
        }
    }

    protected boolean buttonSelected(Button button)
    {
        Button[] buttons = new Button[] {answerButton1, answerButton2, answerButton3, answerButton4};
        selectedButton = button;
        for (int i = 0; i < buttons.length; i++)
        {
            if (buttons[i] != button) {
                buttons[i].setBackgroundColor(Color.WHITE);
            }
            if (this.answer == i + 1)
            {
                answerButton = buttons[i];
            }
        }
        button.setBackgroundColor(Color.LTGRAY);
        if (answerButton == button)
        {
            return true;
        }
        return false;
    }

    public void nextQuestion(View view)
    {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        nextButton = findViewById(R.id.nextButton);
        questionPrompt = findViewById(R.id.questionPrompt);
        questionTitle = findViewById(R.id.questionTitle);
        welcomePrompt = findViewById(R.id.welcomePrompt);
        progressView = findViewById(R.id.progressView);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setProgress(0);
        String Name = getIntent().getStringExtra("Name");
        welcomePrompt.setText("Welcome " + Name + "!");
        Score = getIntent().getIntExtra("Score", 0);
        progressView.setText(Score + "/5");
        int[] sequence = new int[] {1, 2, 3, 4, 5};
        for (int i = 0; i < 5; i++)
        {
            int rand_int = rand.nextInt(4);
            int temp = sequence[i];
            sequence[i] = sequence[rand_int];
            sequence[rand_int] = temp;
        }
        questionNumber = sequence[questions];
        newQuestion();
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                answerTrue = buttonSelected(answerButton1);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                answerTrue = buttonSelected(answerButton2);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                answerTrue = buttonSelected(answerButton3);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                answerTrue = buttonSelected(answerButton4);
            }
        });
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!submitted)
                {
                    if (answerTrue == false)
                    {
                        answerButton.setBackgroundColor(Color.GREEN);
                        selectedButton.setBackgroundColor(Color.RED);
                    }
                    else if (answerTrue == true)
                    {
                        answerButton.setBackgroundColor(Color.GREEN);
                        Score++;
                        progressView.setText(Score + "/5");
                    }
                    else
                    {
                        answerButton.setBackgroundColor(Color.GREEN);
                    }
                    nextButton.setText("Next");
                    submitted = true;
                }
                else
                {
                    questions++;
                    progressBar.setProgress(questions);
                    if (questions >= 5)
                    {
                        Intent intent = new Intent(questionActivity.this, EndActivity.class);
                        intent.putExtra("Name", Name);
                        intent.putExtra("Score", Score);
                        startActivityForResult(intent, RESULT_FIRST_USER);;
                    }
                    questionNumber = sequence[questions];
                    newQuestion();
                }
            }
        });
    }
}
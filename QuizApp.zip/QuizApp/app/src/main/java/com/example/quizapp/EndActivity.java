package com.example.quizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EndActivity extends AppCompatActivity {
    Button finishButton;
    Button newQuizButton;
    TextView resultsView;
    TextView endPrompt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);
        finishButton = findViewById(R.id.finishButton);
        newQuizButton = findViewById(R.id.newQuizButton);
        String Name = getIntent().getStringExtra("Name");
        int Score = getIntent().getIntExtra("Score", 0);
        resultsView = findViewById(R.id.resultsView);
        resultsView.setText(Score + "/5");
        endPrompt = findViewById(R.id.endPrompt);
        endPrompt.setText("Congratulations " + Name + "!");
        finishButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick (View v){
                onDestroy();
            }
        });
        newQuizButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick (View v){
                Intent intent = new Intent(EndActivity.this, questionActivity.class);
                intent.putExtra("Name", Name);
                startActivityForResult(intent, RESULT_FIRST_USER);;
            }
        });
    }


}